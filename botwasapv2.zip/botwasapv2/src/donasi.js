const donasi = () => {
	return `

┏━━━━━━━━━━━━━━━━━━━━
┃ *DONASI*
┃ *BALIKIN KUOTA GUE*
┃ *BANGKE* 
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DONASI TOD* ❉⊰━━✿
┃  
┣━⊱ *DANA*
┣⊱ 0895-7100-73737
┣━⊱ *PULSA*
┣⊱ 0812-4265-3244
┃
┣━━━━━━━━━━━━━━━━━━━━
┃     *MAU PAHALA NGAK*
┗━━━━━━━━━━━━━━━━━━━━

`
}

exports.donasi = donasi
